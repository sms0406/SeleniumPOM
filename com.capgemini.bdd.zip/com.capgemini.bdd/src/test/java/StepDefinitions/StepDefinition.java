package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;

	@Given("^The user is on home page$")
	public void the_user_is_on_home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("http://demowebshop.tricentis.com");
	}

	@Given("^register linktest displayed$")
	public void register_linktest_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User navigate to register page$")
	public void user_navigate_to_register_page() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.className("ico-register")).click();
	}

	@When("^User select appropriate gender$")
	public void user_select_appropriate_gender() throws Throwable {
		Thread.sleep(3000);;
		driver.findElement(By.id("gender-male")).click();
	}

	@When("^User enters valid First Name and Last Name$")
	public void user_enters_valid_First_Name_and_Last_Name() throws Throwable {
		driver.findElement(By.id("FirstName")).sendKeys("Mayank");
		driver.findElement(By.id("LastName")).sendKeys("Sharma");
	}

	@When("^User enter valid EmailID$")
	public void user_enter_valid_EmailID() throws Throwable {
		driver.findElement(By.id("Email")).sendKeys("mayank12491@gmail.com");
	}

	@When("^User enter valid password$")
	public void user_enter_valid_password() throws Throwable {
		driver.findElement(By.id("Password")).sendKeys("demodemo");
	}

	@When("^User re-enter the password$")
	public void user_re_enter_the_password() throws Throwable {
		driver.findElement(By.id("ConfirmPassword")).sendKeys("demodemo");
	}

	@Then("^Message displayed Your registration completed$")
	public void message_displayed_Your_registration_completed() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.name("register-button")).click();
	}

	@Then("^Log out Link displayed$")
	public void log_out_Link_displayed() throws Throwable {
		Thread.sleep(3000);
		driver.close();
	}

}